export interface Music {
    id:string;
    title:string;
    artist:string;
    price:number;
}