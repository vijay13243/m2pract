import { Component, OnInit, ViewChild} from '@angular/core';
import { MusicService } from './music.service';
import { NgForm } from '@angular/forms';
import {Router} from '@angular/router';
import { Music } from './music';

@Component({
  selector: 'app-add-music',
  templateUrl: './add-music.component.html',
  styleUrls: ['./add-music.component.css']
})
export class AddMusicComponent implements OnInit {
  @ViewChild('userForm',{static:false})
  public createMusicForm:NgForm
  constructor(private musicService:MusicService,private router:Router) { }

  ngOnInit() {
  }
  
  onSubmit(music:Music)
  {
    this.musicService.addMusic(music);
    this.router.navigate(['/musics']);
  }

}
