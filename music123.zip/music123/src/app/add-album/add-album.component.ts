import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../albums.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {

  constructor(private service:AlbumsService, private route:Router) { }

  ngOnInit() {
  }

  addAlbum(data:any){
    this.service.addAlbum(data);
    this.route.navigateByUrl('/albumlist');
  }

}
