import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { HomeComponent } from './employee/home.component';
import { EmployeeComponent } from './employee/employee.component';
import { SearchEmployeeComponent } from './employee/search-employee.component';
import { AddEmployeeCanDeactiveRouteGuardService } from './employee/add-employee-can-deactivate-router-guard-service.service';
import { UpdateComponent } from './employee/update.component';


const routes: Routes = [
  { path: "employees", component: EmployeeListComponent },
  { path: "add", component: AddEmployeeComponent, canDeactivate: [AddEmployeeCanDeactiveRouteGuardService] },
  { path: "employees/:id", component: EmployeeComponent },
  { path: "search", component: SearchEmployeeComponent },
  {
    path: 'update/:empid',
    component: UpdateComponent
  },
  { path: '', component: HomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
