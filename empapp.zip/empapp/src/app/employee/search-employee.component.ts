import { Component, OnInit } from '@angular/core';
import { Employee } from './employee.interface';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {
employees:Employee[];
isempty:boolean=false;
  constructor(private serviceservice:ServiceService) { }

  ngOnInit() {
  }
search(data){
   this.isempty=false;
  this.employees=this.serviceservice.getEmployees().filter(emp=>emp.name.toLowerCase()===data.searchTerm);
  if(this.employees.length==0){
    this.employees=this.serviceservice.getEmployees().filter(emp=>emp.gender.toLowerCase()===data.searchTerm);
  }
  if(this.employees.length==0){
   this.isempty=true;
 }
}
}
