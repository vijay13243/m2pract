import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from './employee.interface';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  name: string;
  code: string;
  //name:string;
  gender: string;
  annualSalary: number;
  DateofBirth: string;
  employee: Employee;
  constructor(private route: Router, private activatedRoute: ActivatedRoute, private service: ServiceService) {
    this.activatedRoute.params.subscribe(params => this.name = params.empid);
  }

  ngOnInit() {
    this.employee = this.service.getEmployees().find(emp => emp.name === this.name);
    console.log(this.employee);
  }

  update() {
    if (this.service.updateEmployee(this.employee))
      this.route.navigateByUrl('/employees');
  }

}
