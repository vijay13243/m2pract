import { Component, OnInit } from '@angular/core';
import { IMobile } from './mobile.Interface';
import { MobileService } from './mobile.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  mobiles:IMobile[];
  constructor(private mobileService:MobileService, private router:Router) { }

  ngOnInit() {
  }
  /**
   * This is the add method to add the data and redirect to show and diplay all details
   * @param mobile 
   */
  addMobile(mobile:IMobile){
    console.log(mobile);
    this.mobileService.addMobile(mobile);
    this.router.navigate(['show']);
  }
}

