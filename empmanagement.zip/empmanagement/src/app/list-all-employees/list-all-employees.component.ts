import { Component, OnInit } from '@angular/core';
import {MyserviceService,Employee} from '../myservice.service';
@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {

  createdFlag=true;
  service:MyserviceService;
  constructor(service:MyserviceService) { 
    this.service=service;
  }

  employees:Employee[]=[];
  

  delete(eid:number)
  {
    this.service.delete(eid);
    this.employees=this.service.getEmployees();
  }

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
